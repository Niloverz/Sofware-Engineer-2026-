## Identitas
Nama : Muhammad Ryan Afandi
NIM : 2410511062
Kelas : A

## Deskripsi Layanan
- **Gateway** (port 3000) – Node.js + Express + http-proxy-middleware
- **Service 1** (port 3001) – Layanan Buku (Node.js)
- **Service 2** (port 3002) – Layanan Mahasiswa (PHP)

## Daftar endpoint 
### Service 1 – Buku
| GET    | /service1/books | Ambil semua buku |
| GET    | /service1/books/:id | Ambil buku by ID |
| POST   | /service1/books | Tambah buku baru (JSON: {title, author}) |

### Service 2 – Mahasiswa
| GET    | /service2/students | Ambil semua mahasiswa |
| GET    | /service2/students/:id | Ambil mahasiswa by ID |
| POST   | /service2/students | Tambah mahasiswa (JSON: {name, major}) |

## Cara Menjalankan

1. Clone folder
2. Jalankan masing-masing service di terminal terpisah:
   cd gateway && node server.js
   cd service1-node && node server.js
   cd service2-php && php -S localhost:3002
3. Akses semua endpoint melalui http://localhost:3000/service1/... dan http://localhost:3000/service2/...

## SS Postman
![Hasil Testing Postman](./gambar1.png)
![Hasil Testing Postman](./gambar2.png)
![Hasil Testing Postman](./gambar3.png)
![Hasil Testing Postman](./gambar4.png)
![Hasil Testing Postman](./gambar5.png)
![Hasil Testing Postman](./gambar6.png)



